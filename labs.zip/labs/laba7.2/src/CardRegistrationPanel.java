import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Calendar;

public class CardRegistrationPanel extends JPanel {
    private JTextField cardNumberField, cardHolderField, expiryField;
    private JComboBox<String> cardTypeCombo;
    private JTextArea notesArea;
    private JCheckBox vipCheckBox;
    private ButtonGroup currencyGroup;
    private JButton saveButton, loadButton, clearButton;

    public CardRegistrationPanel() {
        setLayout(new BorderLayout(0, 15));
        setBackground(new Color(255, 240, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Регистрация пластиковой карточки", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(147, 112, 219));
        add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);

        setupInputValidations();
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        formPanel.setBackground(new Color(230, 230, 250));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(216, 191, 216)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        formPanel.add(createLabel("Номер карты:"));
        cardNumberField = new JTextField();
        cardNumberField.setToolTipText("Введите 16 цифр (можно с пробелами или дефисами)");
        formPanel.add(cardNumberField);

        formPanel.add(createLabel("Держатель карты:"));
        cardHolderField = new JTextField();
        cardHolderField.setToolTipText("Имя и Фамилия латинскими буквами");
        formPanel.add(cardHolderField);

        formPanel.add(createLabel("Тип карты:"));
        cardTypeCombo = new JComboBox<>(new String[]{"Visa", "MasterCard", "Maestro", "Мир", "American Express"});
        formPanel.add(cardTypeCombo);

        formPanel.add(createLabel("Срок действия:"));
        expiryField = new JTextField();
        expiryField.setToolTipText("MM/YY (месяц/год)");
        formPanel.add(expiryField);

        formPanel.add(createLabel("Валюта:"));
        JPanel currencyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        currencyPanel.setBackground(new Color(230, 230, 250));
        currencyGroup = new ButtonGroup();

        JRadioButton rubRadio = new JRadioButton("RUB", true);
        JRadioButton usdRadio = new JRadioButton("USD");
        JRadioButton eurRadio = new JRadioButton("EUR");

        currencyGroup.add(rubRadio);
        currencyGroup.add(usdRadio);
        currencyGroup.add(eurRadio);

        currencyPanel.add(rubRadio);
        currencyPanel.add(usdRadio);
        currencyPanel.add(eurRadio);
        formPanel.add(currencyPanel);

        formPanel.add(createLabel("VIP карта:"));
        vipCheckBox = new JCheckBox();
        vipCheckBox.setBackground(new Color(230, 230, 250));
        formPanel.add(vipCheckBox);

        formPanel.add(createLabel("Примечания:"));
        notesArea = new JTextArea(3, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        formPanel.add(new JScrollPane(notesArea));

        return formPanel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        return label;
    }

    private void setupInputValidations() {
        ((AbstractDocument)cardNumberField.getDocument()).setDocumentFilter(new CardNumberFilter());

        ((AbstractDocument)cardHolderField.getDocument()).setDocumentFilter(new HolderNameFilter());

        ((AbstractDocument)expiryField.getDocument()).setDocumentFilter(new ExpiryDateFilter());
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setBackground(new Color(255, 240, 245));

        saveButton = createStyledButton("Сохранить");
        loadButton = createStyledButton("Загрузить");
        clearButton = createStyledButton("Очистить");

        saveButton.addActionListener(this::saveCardData);
        loadButton.addActionListener(this::loadCardData);
        clearButton.addActionListener(this::clearForm);

        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);
        buttonPanel.add(clearButton);

        return buttonPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(216, 191, 216));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(147, 112, 219));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(216, 191, 216));
            }
        });

        return button;
    }

    private void saveCardData(ActionEvent e) {
        try {
            validateCardNumber();
            validateCardHolder();
            validateExpiryDate();

            StringBuilder data = new StringBuilder();
            data.append("Номер карты: ").append(formatCardNumber()).append("\n");
            data.append("Держатель: ").append(cardHolderField.getText()).append("\n");
            data.append("Тип карты: ").append(cardTypeCombo.getSelectedItem()).append("\n");
            data.append("Срок действия: ").append(expiryField.getText()).append("\n");
            data.append("Валюта: ").append(getSelectedCurrency()).append("\n");
            data.append("VIP: ").append(vipCheckBox.isSelected() ? "Да" : "Нет").append("\n");
            data.append("Примечания: ").append(notesArea.getText()).append("\n");
            data.append("----------------------------------\n");

            saveToFile(data.toString());
            JOptionPane.showMessageDialog(this, "Данные карты сохранены!", "Успех", JOptionPane.INFORMATION_MESSAGE);
        } catch (ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Не удалось сохранить данные: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void validateCardNumber() throws ValidationException {
        String cardNumber = cardNumberField.getText().replaceAll("[\\s-]", "");
        if (cardNumber.length() != 16 || !cardNumber.matches("\\d{16}")) {
            throw new ValidationException("Номер карты должен содержать 16 цифр!");
        }
    }

    private void validateCardHolder() throws ValidationException {
        String name = cardHolderField.getText().trim();
        if (!name.matches("[a-zA-Z]+\\s+[a-zA-Z]+")) {
            throw new ValidationException("Введите имя и фамилию латинскими буквами!");
        }
    }

    private void validateExpiryDate() throws ValidationException {
        String expiry = expiryField.getText().trim();
        if (!expiry.matches("(0[1-9]|1[0-2])/\\d{2}")) {
            throw new ValidationException("Срок действия должен быть в формате MM/YY (например 12/25)");
        }

        String[] parts = expiry.split("/");
        int month = Integer.parseInt(parts[0]);
        int year = 2000 + Integer.parseInt(parts[1]);

        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        int currentMonth = now.get(Calendar.MONTH) + 1;

        if (year < currentYear || (year == currentYear && month < currentMonth)) {
            throw new ValidationException("Срок действия карты уже истек!");
        }
    }

    private String formatCardNumber() {
        String cardNumber = cardNumberField.getText().replaceAll("[\\s-]", "");
        return cardNumber.replaceAll("(.{4})", "$1 ").trim();
    }

    private void saveToFile(String data) throws IOException {
        try (FileWriter writer = new FileWriter("cards.txt", true)) {
            writer.write(data);
        }
    }

    private String getSelectedCurrency() {
        for (java.util.Enumeration<AbstractButton> buttons = currencyGroup.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();
            if (button.isSelected()) {
                return button.getText();
            }
        }
        return "";
    }

    private void loadCardData(ActionEvent e) {
        try (BufferedReader reader = new BufferedReader(new FileReader("cards.txt"))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }

            JTextArea textArea = new JTextArea(content.toString());
            textArea.setEditable(false);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 400));

            JOptionPane.showMessageDialog(this, scrollPane, "Загруженные данные карт", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "Не удалось загрузить данные: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm(ActionEvent e) {
        cardNumberField.setText("");
        cardHolderField.setText("");
        cardTypeCombo.setSelectedIndex(0);
        expiryField.setText("");
        currencyGroup.getElements().nextElement().setSelected(true);
        vipCheckBox.setSelected(false);
        notesArea.setText("");
    }
    private class CardNumberFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr)
                throws BadLocationException {
            String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
            if (newText.matches("[\\d\\s-]{0,19}")) {
                super.insertString(fb, offset, text, attr);
                formatCardNumberField();
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            String newText = fb.getDocument().getText(0, offset) + text +
                    fb.getDocument().getText(offset + length, fb.getDocument().getLength() - offset - length);
            if (newText.matches("[\\d\\s-]{0,19}")) {
                super.replace(fb, offset, length, text, attrs);
                formatCardNumberField();
            }
        }

        private void formatCardNumberField() {
            SwingUtilities.invokeLater(() -> {
                String text = cardNumberField.getText().replaceAll("[^\\d]", "");
                if (text.length() > 16) text = text.substring(0, 16);

                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < text.length(); i++) {
                    if (i > 0 && i % 4 == 0) formatted.append(" ");
                    formatted.append(text.charAt(i));
                }

                cardNumberField.setText(formatted.toString());
            });
        }
    }

    private class HolderNameFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr)
                throws BadLocationException {
            if (text.matches("[a-zA-Z\\s]+")) {
                super.insertString(fb, offset, text.toUpperCase(), attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            if (text.matches("[a-zA-Z\\s]+")) {
                super.replace(fb, offset, length, text.toUpperCase(), attrs);
            }
        }
    }

    private class ExpiryDateFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr)
                throws BadLocationException {
            String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
            if (newText.matches("\\d{0,2}/?\\d{0,2}")) {
                super.insertString(fb, offset, text, attr);
                autoInsertSlash();
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            String newText = fb.getDocument().getText(0, offset) + text +
                    fb.getDocument().getText(offset + length, fb.getDocument().getLength() - offset - length);
            if (newText.matches("\\d{0,2}/?\\d{0,2}")) {
                super.replace(fb, offset, length, text, attrs);
                autoInsertSlash();
            }
        }

        private void autoInsertSlash() {
            SwingUtilities.invokeLater(() -> {
                String text = expiryField.getText().replaceAll("[^\\d]", "");
                if (text.length() == 2 && !expiryField.getText().contains("/")) {
                    expiryField.setText(text + "/");
                }
            });
        }
    }

    private class ValidationException extends Exception {
        public ValidationException(String message) {
            super(message);
        }
    }
}