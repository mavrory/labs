import javax.swing.*;
import java.awt.*;

public class CardRegistrationFrame extends JFrame {
    private CardRegistrationPanel cardPanel;

    public CardRegistrationFrame() {
        super("Регистрация пластиковой карты");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 550);
        setLocationRelativeTo(null);

        getContentPane().setBackground(new Color(255, 240, 245));

        cardPanel = new CardRegistrationPanel();
        add(cardPanel);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                if (JOptionPane.showConfirmDialog(CardRegistrationFrame.this,
                        "Вы уверены, что хотите выйти?", "Подтверждение выхода",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }
}