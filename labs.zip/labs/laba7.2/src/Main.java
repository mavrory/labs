import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CardRegistrationFrame frame = new CardRegistrationFrame();
            frame.setVisible(true);
        });
    }
}