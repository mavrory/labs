
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Main extends JFrame {
    private JList<String> list1, list2, list3;
    private DefaultListModel<String> model1, model2, model3;
    private JButton moveSelectedBtn, moveAllBtn, addBtn, editBtn, deleteBtn;

    public Main() {
        super("Управление списками");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
        setLayout(new BorderLayout());

        getContentPane().setBackground(new Color(255, 218, 233));
        model1 = new DefaultListModel<>();
        model2 = new DefaultListModel<>();
        model3 = new DefaultListModel<>();

        String[] items1 = {"Элемент 1", "Элемент 2", "Элемент 3"};
        String[] items2 = {"Объект A", "Объект B", "Объект C"};
        String[] items3 = {"Пункт I", "Пункт II", "Пункт III"};

        for (String item : items1) model1.addElement(item);
        for (String item : items2) model2.addElement(item);
        for (String item : items3) model3.addElement(item);

        list1 = createStyledList(model1);
        list2 = createStyledList(model2);
        list3 = createStyledList(model3);

        JPanel listsPanel = new JPanel(new GridLayout(1, 3));
        listsPanel.add(new JScrollPane(list1));
        listsPanel.add(new JScrollPane(list2));
        listsPanel.add(new JScrollPane(list3));

        JPanel buttonsPanel = new JPanel(new FlowLayout());
        buttonsPanel.setBackground(new Color(230, 230, 250));

        moveSelectedBtn = createStyledButton("Переместить выбранное");
        moveAllBtn = createStyledButton("Переместить все");
        addBtn = createStyledButton("Добавить");
        editBtn = createStyledButton("Редактировать");
        deleteBtn = createStyledButton("Удалить");

        buttonsPanel.add(moveSelectedBtn);
        buttonsPanel.add(moveAllBtn);
        buttonsPanel.add(addBtn);
        buttonsPanel.add(editBtn);
        buttonsPanel.add(deleteBtn);

        add(listsPanel, BorderLayout.CENTER);
        add(buttonsPanel, BorderLayout.SOUTH);

        moveSelectedBtn.addActionListener(e -> moveSelectedItems());
        moveAllBtn.addActionListener(e -> moveAllItems());
        addBtn.addActionListener(e -> addItem());
        editBtn.addActionListener(e -> editItem());
        deleteBtn.addActionListener(e -> deleteItem());
    }

    private JList<String> createStyledList(DefaultListModel<String> model) {
        JList<String> list = new JList<>(model);
        list.setBackground(new Color(255, 240, 245));
        list.setSelectionBackground(new Color(221, 160, 221));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        return list;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(216, 191, 216));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        return button;
    }

    private void moveSelectedItems() {
        if (!list1.isSelectionEmpty()) {
            String selected = list1.getSelectedValue();
            model2.addElement(selected);
            model1.removeElement(selected);
        }
        else if (!list2.isSelectionEmpty()) {
            String selected = list2.getSelectedValue();
            model3.addElement(selected);
            model2.removeElement(selected);
        }
        else if (!list3.isSelectionEmpty()) {
            String selected = list3.getSelectedValue();
            model1.addElement(selected);
            model3.removeElement(selected);
        }
    }

    private void moveAllItems() {
        if (!model1.isEmpty()) {
            ArrayList<String> items = new ArrayList<>();
            for (int i = 0; i < model1.size(); i++) {
                items.add(model1.getElementAt(i));
            }
            for (String item : items) {
                model2.addElement(item);
                model1.removeElement(item);
            }
        }
        else if (!model2.isEmpty()) {
            ArrayList<String> items = new ArrayList<>();
            for (int i = 0; i < model2.size(); i++) {
                items.add(model2.getElementAt(i));
            }
            for (String item : items) {
                model3.addElement(item);
                model2.removeElement(item);
            }
        }
        else if (!model3.isEmpty()) {
            ArrayList<String> items = new ArrayList<>();
            for (int i = 0; i < model3.size(); i++) {
                items.add(model3.getElementAt(i));
            }
            for (String item : items) {
                model1.addElement(item);
                model3.removeElement(item);
            }
        }
    }

    private void addItem() {
        String newItem = JOptionPane.showInputDialog(this, "Введите новый элемент:", "Добавление", JOptionPane.PLAIN_MESSAGE);
        if (newItem != null && !newItem.trim().isEmpty()) {
            model2.addElement(newItem.trim());
        }
    }

    private void editItem() {
        int selectedIndex = list2.getSelectedIndex();
        if (selectedIndex != -1) {
            String currentValue = model2.getElementAt(selectedIndex);
            String newValue = JOptionPane.showInputDialog(this, "Редактирование:", currentValue);
            if (newValue != null && !newValue.trim().isEmpty()) {
                model2.set(selectedIndex, newValue.trim());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Выберите элемент для редактирования", "Ошибка", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void deleteItem() {
        int selectedIndex = list2.getSelectedIndex();
        if (selectedIndex != -1) {
            model2.remove(selectedIndex);
        } else {
            JOptionPane.showMessageDialog(this, "Выберите элемент для удаления", "Ошибка", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main app = new Main();
            app.setVisible(true);
        });
    }
}
