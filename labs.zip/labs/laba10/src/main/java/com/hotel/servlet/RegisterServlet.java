package com.hotel.servlet;

import com.hotel.dao.UserDAO;
import com.hotel.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("showRegister", true);
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String login = req.getParameter("login");
        String password = req.getParameter("password");
        String name = req.getParameter("name");

        if (userDAO.findByLogin(login) != null) {
            req.setAttribute("error", "Пользователь с таким логином уже существует");
            req.setAttribute("showRegister", true);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        User newUser = new User(login, password);
        boolean created = userDAO.createUser(newUser);

        if (created) {
            req.getSession(true).setAttribute("user", newUser);
            resp.sendRedirect(req.getContextPath() + "/user");
        } else {
            req.setAttribute("error", "Ошибка при создании пользователя");
            req.setAttribute("showRegister", true);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}