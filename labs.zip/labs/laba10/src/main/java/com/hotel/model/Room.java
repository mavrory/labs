
package com.hotel.model;

public class Room {
    private int id;
    private String type;
    private double price;
    private boolean booked;

    public Room() {}

    public Room(int id, String type, double price, boolean booked) {
        this.id = id;
        this.type = type;
        this.price = price;
        this.booked = booked;
    }

    public Room(String type, double price) {
        this.type = type;
        this.price = price;
        this.booked = false;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isBooked() { return booked; }
    public void setBooked(boolean booked) { this.booked = booked; }
}
