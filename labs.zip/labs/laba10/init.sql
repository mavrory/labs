
-- SQL для PostgreSQL
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    login VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
    id SERIAL PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    price NUMERIC(10,2) NOT NULL,
    is_booked BOOLEAN NOT NULL DEFAULT FALSE
);

-- Пример данных
INSERT INTO users (login, password, role) VALUES
('admin', 'admin', 'ADMIN')
ON CONFLICT (login) DO NOTHING;
