import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Main extends JFrame {

    private BufferedImage carImage, personImage, treeImage, edwardImage, backgroundImage;

    private final int carWidth = 300, carHeight = 200;
    private final int personWidth = 60, personHeight = 120;
    private final int treeBaseY = 300;
    private final int edwardWidth = 80, edwardHeight = 120;

    private int carX = -150, carY = 200;
    private final int personX = 400, personY = 280;
    private int treeX = 200, treeHeight = 120, treeWidth = 80;
    private int edwardX = 800, edwardY = 280;

    private volatile boolean running = false;
    private JButton startButton, stopButton;

    public Main() {
        setTitle("Сцена: Белла и Эдвард");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            carImage = scaleImage(ImageIO.read(getClass().getResource("car.png")), carWidth, carHeight);
            personImage = scaleImage(ImageIO.read(getClass().getResource("person.png")), personWidth, personHeight);
            treeImage = scaleImage(ImageIO.read(getClass().getResource("tree.png")), treeWidth, treeHeight);
            edwardImage = scaleImage(ImageIO.read(getClass().getResource("edward.png")), edwardWidth, edwardHeight);
            backgroundImage = scaleImage(ImageIO.read(getClass().getResource("background.jpg")), 800, 500);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Ошибка загрузки изображений", "Ошибка", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        JPanel drawingPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null)
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);

                g.drawImage(treeImage, treeX, treeBaseY - treeHeight, treeWidth, treeHeight, this);

                g.drawImage(personImage, personX, personY, personWidth, personHeight, this);

                g.drawImage(edwardImage, edwardX, edwardY, edwardWidth, edwardHeight, this);

                g.drawImage(carImage, carX, carY, carWidth, carHeight, this);
            }
        };

        JPanel buttonPanel = new JPanel();
        startButton = new JButton("Старт");
        stopButton = new JButton("Стоп");
        stopButton.setEnabled(false);

        startButton.addActionListener(e -> {
            if (!running) {
                running = true;
                startButton.setEnabled(false);
                stopButton.setEnabled(true);

                new Thread(new CarThread()).start();
                new Thread(new EdwardThread()).start();
                new Thread(new TreeThread()).start();
            }
        });

        stopButton.addActionListener(e -> {
            running = false;
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        });

        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);

        setLayout(new BorderLayout());
        add(drawingPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private BufferedImage scaleImage(BufferedImage original, int width, int height) {
        if (original == null) {
            BufferedImage blank = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = blank.createGraphics();
            g2d.setColor(Color.RED);
            g2d.fillRect(0, 0, width, height);
            g2d.dispose();
            return blank;
        }

        BufferedImage scaled = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = scaled.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(original, 0, 0, width, height, null);
        g2d.dispose();
        return scaled;
    }

    private class CarThread implements Runnable {
        @Override
        public void run() {
            while (running) {
                carX += 4;
                if (carX + carWidth >= personX - 10) {
                    carX = personX - carWidth + 10;
                    repaint();
                    try { Thread.sleep(2000); } catch (InterruptedException e) {}
                    resetScene();
                }
                repaint();
                try { Thread.sleep(30); } catch (InterruptedException e) {}
            }
        }
    }

    private class EdwardThread implements Runnable {
        @Override
        public void run() {
            while (running) {
                edwardX = 800;
                while (running && carX + carWidth < personX - 100) {
                    try { Thread.sleep(30); } catch (InterruptedException e) {}
                }

                while (running && edwardX > personX - edwardWidth + 20) {
                    edwardX -= 20;
                    repaint();
                    try { Thread.sleep(30); } catch (InterruptedException e) {}
                }

                repaint();
                try { Thread.sleep(2000); } catch (InterruptedException e) {}
            }
        }
    }

    private class TreeThread implements Runnable {
        @Override
        public void run() {
            while (running) {
                if (treeHeight < 250) {
                    treeHeight += 2;
                    treeWidth = (int) (treeHeight * 0.66);
                    repaint();
                }
                try { Thread.sleep(200); } catch (InterruptedException e) {}
            }
        }
    }

    private void resetScene() {
        carX = -carWidth;
        edwardX = 800;
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}













//import javax.imageio.ImageIO;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.awt.image.BufferedImage;
//import java.io.IOException;
//import java.util.Random;
//
//public class Main extends JFrame {
//
//    private BufferedImage carImage, personImage, treeImage;
//
//    private int carWidth = 150, carHeight = 80;
//    private int personWidth = 60, personHeight = 120;
//    private int treeWidth = 80, treeHeight = 120;
//
//    private int carX = -150, carY = 250;
//    private int personX = 400, personY = 280;
//    private int treeX = 200, treeBaseY = 300;
//
//    private volatile boolean running = false;
//    private JButton startButton, stopButton;
//
//    public Main() {
//        setTitle("Машина, человек и дерево");
//        setSize(800, 500);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLocationRelativeTo(null);
//
//        try {
//            carImage = scaleImage(ImageIO.read(getClass().getResource("car.png")), carWidth, carHeight);
//            personImage = scaleImage(ImageIO.read(getClass().getResource("person.png")), personWidth, personHeight);
//            treeImage = scaleImage(ImageIO.read(getClass().getResource("tree.png")), treeWidth, treeHeight);
//        } catch (IOException e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(this, "Ошибка загрузки изображений", "Ошибка", JOptionPane.ERROR_MESSAGE);
//            System.exit(1);
//        }
//
//        JPanel drawingPanel = new JPanel() {
//            @Override
//            protected void paintComponent(Graphics g) {
//                super.paintComponent(g);
//                // Отрисовка фона
//                g.setColor(new Color(135, 206, 235));
//                g.fillRect(0, 0, getWidth(), getHeight() / 2);
//                g.setColor(new Color(34, 139, 34));
//                g.fillRect(0, getHeight() / 2, getWidth(), getHeight() / 2);
//
//                // Отрисовка объектов
//                g.drawImage(treeImage, treeX, treeBaseY - treeHeight, treeWidth, treeHeight, this);
//                g.drawImage(personImage, personX, treeBaseY - personHeight, personWidth, personHeight, this);
//                g.drawImage(carImage, carX, carY, carWidth, carHeight, this);
//            }
//        };
//
//        JPanel buttonPanel = new JPanel();
//        startButton = new JButton("Старт");
//        stopButton = new JButton("Стоп");
//        stopButton.setEnabled(false);
//
//        startButton.addActionListener(e -> {
//            if (!running) {
//                running = true;
//                startButton.setEnabled(false);
//                stopButton.setEnabled(true);
//
//                new Thread(new CarThread()).start();
//                new Thread(new PersonThread()).start();
//                new Thread(new TreeThread()).start();
//            }
//        });
//
//        stopButton.addActionListener(e -> {
//            running = false;
//            startButton.setEnabled(true);
//            stopButton.setEnabled(false);
//        });
//
//        buttonPanel.add(startButton);
//        buttonPanel.add(stopButton);
//
//        setLayout(new BorderLayout());
//        add(drawingPanel, BorderLayout.CENTER);
//        add(buttonPanel, BorderLayout.SOUTH);
//    }
//
//    private BufferedImage scaleImage(BufferedImage original, int width, int height) {
//        if (original == null) {
//            BufferedImage blank = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
//            Graphics2D g2d = blank.createGraphics();
//            g2d.setColor(Color.RED);
//            g2d.fillRect(0, 0, width, height);
//            g2d.dispose();
//            return blank;
//        }
//
//        BufferedImage scaled = new BufferedImage(width, height, original.getType());
//        Graphics2D g2d = scaled.createGraphics();
//        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
//        g2d.drawImage(original, 0, 0, width, height, null);
//        g2d.dispose();
//        return scaled;
//    }
//
//    private class CarThread implements Runnable {
//        @Override
//        public void run() {
//            while (running) {
//                carX += 5;
//                if (carX > getWidth()) {
//                    carX = -carWidth;
//                }
//                repaint();
//                try { Thread.sleep(50); } catch (InterruptedException e) {}
//            }
//        }
//    }
//
//    private class PersonThread implements Runnable {
//        private Random random = new Random();
//        private double personXDouble = personX;
//        private double velocity = 0;
//
//        @Override
//        public void run() {
//            while (running) {
//                velocity += (random.nextDouble() - 0.5) * 0.2;
//                velocity = Math.max(-1.5, Math.min(1.5, velocity));
//
//                personXDouble += velocity;
//
//
//                if (personXDouble < 0) {
//                    personXDouble = 0;
//                    velocity = -velocity * 0.5;
//                }
//                if (personXDouble > getWidth() - personWidth) {
//                    personXDouble = getWidth() - personWidth;
//                    velocity = -velocity * 0.5;
//                }
//
//                personX = (int) personXDouble;
//                repaint();
//                try {
//                    Thread.sleep(30);
//                } catch (InterruptedException e) {}
//            }
//        }
//    }
//
//
////    private class PersonThread implements Runnable {
////        private Random random = new Random();
////
////        @Override
////        public void run() {
////            while (running) {
////                personX += random.nextInt(3) - 1;
////                if (personX < 0) personX = 0;
////                if (personX > getWidth() - personWidth) {
////                    personX = getWidth() - personWidth;
////                }
////                repaint();
////                try { Thread.sleep(100); } catch (InterruptedException e) {}
////            }
////        }
////    }
//
//    private class TreeThread implements Runnable {
//        @Override
//        public void run() {
//            while (running && treeHeight < 250) {
//                treeHeight += 2;
//                treeWidth = (int)(treeHeight * 0.66);
//                repaint();
//                try { Thread.sleep(200); } catch (InterruptedException e) {}
//            }
//        }
//    }
//
//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
//    }
//}