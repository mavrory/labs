
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    private static final int TECHNICAL_BREAK_INTERVAL = 45;
    private static final int TECHNICAL_BREAK_DURATION = 10;

    private static AtomicInteger totalCustomers;
    private static int[] servedCustomers = new int[3];
    private static long simulationStartTime;
    private static boolean simulationRunning = false;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        int[] serviceTimes = {2, 3, 3};
        int customersTotal = 250;

        do {
            printMenu();
            choice = getIntInput(scanner, "Выберите пункт меню: ", 1, 5);

            switch (choice) {
                case 1:
                    System.out.println("\n=== Настройка параметров ===");
                    serviceTimes[0] = getTimeInput(scanner, "Время обслуживания 1-го кассира (мин): ");
                    serviceTimes[1] = getTimeInput(scanner, "Время обслуживания 2-го кассира (мин): ");
                    serviceTimes[2] = getTimeInput(scanner, "Время обслуживания 3-го кассира (мин): ");
                    customersTotal = getIntInput(scanner, "Общее количество покупателей: ", 1, 10000);
                    break;

                case 2:
                    System.out.println("\n=== Текущие параметры ===");
                    System.out.println("1-й кассир: " + serviceTimes[0] + " мин на покупателя");
                    System.out.println("2-й кассир: " + serviceTimes[1] + " мин на покупателя");
                    System.out.println("3-й кассир: " + serviceTimes[2] + " мин на покупателя");
                    System.out.println("Общее количество покупателей: " + customersTotal);
                    System.out.println("Технический перерыв: каждые " + TECHNICAL_BREAK_INTERVAL +
                            " мин, продолжительность " + TECHNICAL_BREAK_DURATION + " мин");
                    break;

                case 3:
                    if (simulationRunning) {
                        System.out.println("Симуляция уже запущена!");
                        break;
                    }
                    System.out.println("\n=== Запуск симуляции ===");
                    totalCustomers = new AtomicInteger(customersTotal);
                    servedCustomers = new int[3];
                    startSimulation(serviceTimes);
                    break;

                case 4:
                    System.out.println("\n=== Справка ===");
                    System.out.println("В симуляции 1 мс = 1 минута реального времени");
                    System.out.println("Кассиры работают параллельно со своей скоростью");
                    System.out.println("Технические перерывы: каждые " + TECHNICAL_BREAK_INTERVAL +
                            " мин на " + TECHNICAL_BREAK_DURATION + " мин");
                    break;
            }

            if (choice != 5) {
                System.out.println("\nНажмите Enter, чтобы продолжить...");
                scanner.nextLine();
            }
        } while (choice != 5);

        System.out.println("Программа завершена.");
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n=== Театральная касса ===");
        System.out.println("1. Настроить параметры");
        System.out.println("2. Просмотреть текущие параметры");
        System.out.println("3. Запустить симуляцию");
        System.out.println("4. Справка");
        System.out.println("5. Выход");
    }

    private static void startSimulation(int[] serviceTimes) {
        simulationRunning = true;
        simulationStartTime = System.currentTimeMillis();

        Thread cashier1 = new Thread(new Cashier(1, serviceTimes[0]));
        Thread cashier2 = new Thread(new Cashier(2, serviceTimes[1]));
        Thread cashier3 = new Thread(new Cashier(3, serviceTimes[2]));

        cashier1.start();
        cashier2.start();
        cashier3.start();

        new Thread(() -> {
            try {
                cashier1.join();
                cashier2.join();
                cashier3.join();

                long totalSimulationTime = System.currentTimeMillis() - simulationStartTime;

                System.out.println("\n=== Результаты симуляции ===");
                System.out.printf("Общее время работы: %d мин (реально: %d мс)\n",
                        totalSimulationTime, totalSimulationTime);
                System.out.println("1-й кассир обслужил: " + servedCustomers[0] + " покупателей");
                System.out.println("2-й кассир обслужил: " + servedCustomers[1] + " покупателей");
                System.out.println("3-й кассир обслужил: " + servedCustomers[2] + " покупателей");

                simulationRunning = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    static class Cashier implements Runnable {
        private final int id;
        private final int serviceTime;
        private int customersServed = 0;
        private long workingTime = 0;

        public Cashier(int id, int serviceTime) {
            this.id = id;
            this.serviceTime = serviceTime;
        }

        @Override
        public void run() {
            while (totalCustomers.get() > 0) {
                if (workingTime >= TECHNICAL_BREAK_INTERVAL) {
                    System.out.printf("[%03d мин] Кассир %d ушел на перерыв\n",
                            (System.currentTimeMillis() - simulationStartTime), id);
                    try {
                        Thread.sleep(TECHNICAL_BREAK_DURATION);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                    workingTime = 0;
                    System.out.printf("[%03d мин] Кассир %d вернулся с перерыва\n",
                            (System.currentTimeMillis() - simulationStartTime), id);
                }

                if (totalCustomers.decrementAndGet() >= 0) {
                    long startService = System.currentTimeMillis();
                    try {
                        Thread.sleep(serviceTime);
                        customersServed++;
                        servedCustomers[id-1] = customersServed;
                        workingTime += serviceTime;
                        System.out.printf("[%03d мин] Кассир %d обслужил %d покупателя (осталось %d)\n",
                                (System.currentTimeMillis() - simulationStartTime),
                                id, customersServed, totalCustomers.get());
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                } else {
                    totalCustomers.incrementAndGet();
                    break;
                }
            }
        }
    }

    private static int getIntInput(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = scanner.nextInt();
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("Введите число от %d до %d!\n", min, max);
            } catch (InputMismatchException e) {
                System.out.println("Ошибка: введите целое число!");
                scanner.nextLine();
            }
        }
    }

    private static int getTimeInput(Scanner scanner, String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int minutes = scanner.nextInt();
                if (minutes > 0) {
                    return minutes;
                }
                System.out.println("Введите положительное число!");
            } catch (InputMismatchException e) {
                System.out.println("Ошибка: введите целое число!");
                scanner.nextLine();
            }
        }
    }
}
